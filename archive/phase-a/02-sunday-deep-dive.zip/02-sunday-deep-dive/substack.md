Subject: Six primitives, not features.
Preheader: The architectural spine that makes SZL Holdings structurally different from dashboards, copilots, and workflow tools.

---

# Six primitives, not features.

*Post 2 of 3 in the SZL Holdings launch series.*

---

There is a structural reason why most enterprise software ends up as a collection of features rather than a governed system. Features are the natural unit of product development. Primitives are different.

Primitives are the structural constraints and capabilities that determine what a platform can do — not just in one domain, but across every domain built on top of it. Primitives cannot be added later. They have to be designed in.

SZL Holdings is built on six. Here is what each one does — and concretely, how the same primitive operates inside a SOC alert in Aegis, a voyage P&L call in Vessels, and a listing decision in Terra simultaneously.

---

**Outcome Graph** — Tracks the full decision lifecycle: recommendation → decision → outcome. Every decision is linked to its signal, the AI recommendation, and the observed result. Closed-loop learning — agents calibrate against what actually happened. No other layer in the stack does this.

---

**Proof Chain** — Immutable, append-only audit trail with provenance for every action. AI outputs carry model identity and source citations. Human actions carry actor attribution. Compliance teams can reconstruct any decision chain. This is not a log — it is a verifiable chain of custody.

---

**Covenant Policy** — Permission and approval gates enforced at the platform layer, not the UI layer. An AI agent cannot execute a consequential action without passing through Covenant Policy. Human-in-the-loop is not a button. It is a structural constraint enforced by the Alloy execution fabric.

---

**Decision Simulation** — Probabilistic modeling before action. Confidence intervals, sensitivity analysis, and scenario comparisons before the operator commits. The platform shows not just "what should we do" but "what could happen if we do it" — and what the probability distribution looks like across scenarios.

---

**Workflow Engine** — Durable multi-step process orchestration with agent coordination and checkpoint recovery. Complex decisions are tracked, governed, and recoverable — not opaque one-shots that either succeed silently or fail without attribution.

---

**Event Fabric** — Cross-domain signal backbone. Normalizes and routes signals from maritime, security, real estate, and legal. A sanctions hit in Vessels surfaces a legal risk flag in PRISM Counsel automatically. One signal. Cross-domain consequence.

---

The same six primitives power a SOC alert in Aegis, a voyage P&L call in Vessels, a listing decision in Terra, and a matter triage in PRISM Counsel. Different domains, same spine. That is what the one-platform claim actually means at the code level.

---

Thursday's post introduced the full hierarchy and the accountability thesis: [read it here](https://szlholdings.substack.com).

Monday's post walks one real governed decision — a maritime sanctions alert — from signal to proof, step by step. It is the most concrete thing in the series and the right read for practitioners evaluating the platform.

---

Platform: [szlholdings.com](https://szlholdings.com)
GitHub: [github.com/stephenlutar2-hash/szl-holdings-platform](https://github.com/stephenlutar2-hash/szl-holdings-platform)
LinkedIn: [linkedin.com/in/stephen-l-279315240](https://linkedin.com/in/stephen-l-279315240)

Design partner inquiries: **inquiries@szlholdings.com**

---

*Post 2 of 3. See you Monday.*
