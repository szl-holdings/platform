SZL COMMAND — NEWSLETTER SCREENSHOTS KIT
===========================================

Purpose
-------
Visual reference kit for the SZL Substack and Medium launch. Pair these
images with the two PDF strategy documents:
  - SZL-Substack-Launch-Plan.pdf
  - SZL-Medium-Launch-Plan.pdf

Folder contents
---------------

/mockups — branded mockups rendered in SZL Holdings brand language
(obsidian + gold, Space Grotesk / Inter / JetBrains Mono). Use these
when briefing a designer, when previewing visuals with investors, or
when setting up the live publications. Each mockup is 2x resolution
PNG for retina clarity.

  substack-home.png
      Substack homepage mockup — shows how the SZL Command landing page should look, including hero gradient, gold brand mark, subscribe CTA, and three featured post cards.

  substack-about.png
      Substack about-page mockup — shows the positioning, pillar chips, paid-tier callout, and audience section.

  substack-welcome-email.png
      Welcome email mockup — exactly what a new subscriber receives, ready to paste into the Substack welcome-email editor.

  substack-post.png
      Substack post mockup — long-form post layout with gradient cover, gold drop cap, Source Serif body. Use as a visual target when formatting posts.

  medium-publication.png
      Medium publication-page mockup — how the SZL Command publication on Medium should appear, including tabs for each pillar.

  medium-article.png
      Medium article mockup — single-post layout on Medium, including tag chips and member-program formatting.

/references — screenshots of best-in-class Substack and Medium
publications in adjacent spaces. Use these as reference for
editorial voice, cadence, and visual direction. Screenshots are
captured at launch time; if a page has changed since capture,
the structural reference still holds.

  01-stratechery.png
      Stratechery by Ben Thompson — Gold standard for paid tech-strategy long-form. Model for our voice, cadence, and paid tier.

  02-not-boring.png
      Not Boring by Packy McCormick — Model for narrative-heavy deep dives with strong visual identity. Reference for hero illustration style.

  03-lennys-newsletter.png
      Lenny's Newsletter — Best-in-class monetization and community motion on Substack. Reference for paid-tier structure.

  04-the-generalist.png
      The Generalist by Mario Gabriele — Strong investor-adjacent audience, company deep-dive format, clean visual system.

  05-every.png
      Every (Dan Shipper et al.) — Multi-pillar publication model — closest to our six-pillar structure. Good reference for calendar rhythm.

  06-platformer.png
      Platformer by Casey Newton — Beat-reporter Substack with sharp paid tier and tight cadence. Reference for industry-news rhythm.

  07-bens-bites.png
      Ben's Bites — High-velocity AI newsletter with strong visual identity and growth motion. Reference for fast-cadence ops.

  08-the-pragmatic-engineer.png
      The Pragmatic Engineer by Gergely Orosz — Top-grossing technical Substack. Reference for engineering-essay pillar pricing and structure.

How to use this kit
-------------------
1. Read the Substack PDF first. Follow the setup checklist in order.
2. Use mockups/substack-home.png, substack-about.png, and
   substack-welcome-email.png as the visual target while you set up
   the publication.
3. When cross-posting to Medium, use mockups/medium-publication.png
   and medium-article.png as the visual target.
4. Reference /references/ for editorial voice and cadence
   calibration across the 90-day calendar.

Questions → reply to any SZL Command essay.

Version: 1.0 · Generated on 2026-04-16
